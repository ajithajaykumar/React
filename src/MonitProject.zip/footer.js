import './style.css'
function footer(){
    return(
        <>
        <footer>
        <div className="footer">
         <h1>A School Portal For  student</h1>
         <div className="footDetails">
         <ul >
            <li><h2>FrontEnd</h2></li>
            <li><h3>Html</h3></li>
            <li><h3>Css</h3></li>
            <li><h3>JavaScript</h3></li>
            </ul>
            <ul>
            <li><h2>Back End</h2></li>
            <li><h3>Core Java</h3></li>
            <li><h3>Java Server Page</h3></li>
            <li><h3>JDBC</h3></li>
            <li><h3>servlet</h3></li>
            </ul>
            <ul >
            <li><h2>Java FrameWork</h2></li>
            <li><h3>Spring</h3></li>
            <li><h3>HyperNet</h3></li>
            <li><h3>Spring Boot</h3></li>
            </ul>
            <ul >
            <li><h2>DataBase</h2></li>
            <li><h3>Mysql</h3></li>
            <li><h3>Mssql</h3></li>
            <li><h3>MongoDB</h3></li>
            </ul>
         </div>
        </div>
        </footer>
        </>
    )
}
export default footer