
import './style.css'
function html(){
    return(
        <>
        <div style={{backgroundColor:"red",color:"black",textAlign:"center",width:'fill'}} className='home disableScroll'>
        <h1>HTML is the standard markup language for Web pages.

With HTML you can create your own Website.

HTML is easy to learn - You will enjoy it!</h1>

        </div>
        </>
    )
}
export default html