import Route from './ProjectMonit/router'
// import {BrowserRouter,Routes,Route,Link} from 'react-router-dom' 
// import './component/Route.css';
// import Home from './component/Home'
// import Stu from './component/StudentDetail'
// import Teacher from './component/Teacher'
// import School from './component/school'
{/* <BrowserRouter>
<ul>
 <li><Link to="/">Home</Link></li>
 <li><Link to="/Student">StudentPage</Link></li>
 <li><Link to="/Teacher">TeacherPage</Link></li>
 <li><Link to="/School">SchoolDetails</Link></li>
</ul>
<Routes>
 <Route path="/" element={<Home/>}/>
 <Route path="/Student" element={<Stu/>}/>
 <Route path="/Teacher" element={<Teacher/>}/>
 <Route path="/School" element={<School/>}/>
</Routes>
</BrowserRouter> */}
function App() {
  return (
         <Route />
  );
}

export default App;
